  ____                _                
 |  _ \ ___  __ _  __| |_ __ ___   ___ 
 | |_) / _ \/ _` |/ _` | '_ ` _ \ / _ \
 |  _ <  __/ (_| | (_| | | | | | |  __/
 |_| \_\___|\__,_|\__,_|_| |_| |_|\___|
                                      
                                      

Contents of this archive:

    * bulldog.<boardname>.jar
        the libbulldog jar for your board 
        
    * libbulldog-linux.so
        the native binary for your linux distribution (libbulldog-linux.so)
        
    * license.txt
        licensing information for this software
        
    * readme.txt
        this file


Installation:

    Just copy the native library and the jar to the place you want them to be.
    They must be in the same directory. Then, just use the jar in your project
    like you would use any other jar.